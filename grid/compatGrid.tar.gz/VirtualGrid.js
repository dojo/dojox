dojo.provide("dojox.grid.VirtualGrid");
dojo.require("dojox.grid.compat.VirtualGrid");
dojo.deprecated("dojox.grid.VirtualGrid");
